<?php $__env->startSection('title', 'Minigolf - Mundial'); ?>

<?php $__env->startSection('content'); ?>
<main id="main-content" class="main-content">
  <div class="w-container">
    <a href="<?php echo e(route('offers')); ?>" class="back w-inline-block">
      <img src="<?php echo e(asset('images/back.svg')); ?>" loading="lazy" alt="" class="image-26">
      <div class="text-block-7"><?php echo e(trans_db('offer.back_to_offers', null, 'À la liste des offres')); ?></div>
    </a>
  </div>
  <div class="w-container">
    <div class="div-block-47"></div>
    <div class="w-richtext">
      <p>‍</p>
      <h2><strong><?php echo e(trans_db('offer.minigolf.title', null, 'Minigolf')); ?></strong></h2>
      <p><?php echo trans_db('offer.minigolf.desc1', null, 'Profitez d\'une partie de mini-golf sur notre terrain de mini-golf. Notre mini-golf de 20 trous est situé au cœur de notre parc naturel. Nature et plaisir pour toute la famille ! La longueur supplémentaire de certains trous est un défi particulier et garantit le plaisir de jouer !'); ?></p>
      <p><?php echo trans_db('offer.minigolf.desc2', null, 'Vous avez une occasion spéciale ? Pas de problème, car avec nous, vous pouvez aussi faire la fête ensemble. Des fêtes d\'anniversaire inoubliables pour les enfants ou un événement d\'entreprise sont possibles sur demande.'); ?></p>
      <p>‍</p>
    </div>
    <div class="div-block-209">
      <a href="#" class="primary-button w-button"><?php echo e(trans_db('offer.button_book', null, 'Réserver')); ?></a>
    </div>
  </div>
  <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/home/cerita_oca/Documents/iza/mundial_project1/mundial/resources/views/angebote-minigolf.blade.php ENDPATH**/ ?>