<?php
    $id = $getId();
    $statePath = $getStatePath();
?>

<div x-data="{ id: <?php echo \Illuminate\Support\Js::from($id)->toHtml() ?> }" class="fi-fo-field-wrp">
    <div class="tinymce-wrapper">
        <textarea
            id="<?php echo e($id); ?>"
            wire:model.defer="<?php echo e($statePath); ?>"
            class="tinymce-editor"
        ><?php echo e($getState()); ?></textarea>
    </div>
</div>

    <?php
        $__assetKey = '1547629297-0';

        ob_start();
    ?>
    <script src="https://cdn.jsdelivr.net/npm/tinymce@6/tinymce.min.js"></script>
    <?php
        $__output = ob_get_clean();

        // If the asset has already been loaded anywhere during this request, skip it...
        if (in_array($__assetKey, \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys)) {
            // Skip it...
        } else {
            \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys[] = $__assetKey;

            // Check if we're in a Livewire component or not and store the asset accordingly...
            if (isset($this)) {
                \Livewire\store($this)->push('assets', $__output, $__assetKey);
            } else {
                \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$nonLivewireAssets[$__assetKey] = $__output;
            }
        }
    ?>

    <?php
        $__scriptKey = '1547629297-1';
        ob_start();
    ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        tinymce.init({
            selector: '#<?php echo e($id); ?>',
            license_key: 'gpl',
            plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount',
            toolbar: 'undo redo | formatselect | bold italic underline strikethrough | link image media table | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat',
            menubar: 'file edit view insert format tools table help',
            height: 400,
            promotion: false,
            branding: false,
            content_css: false,
            setup: function(editor) {
                editor.on('change', function() {
                    let value = editor.getContent();
                    window.livewire.find(document.querySelector('[wire\\:id]').getAttribute('wire:id')).set(<?php echo \Illuminate\Support\Js::from($statePath)->toHtml() ?>, value);
                });
            }
        });
    });
</script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>

<style>
    .tinymce-wrapper {
        position: relative;
        margin-top: 0.5rem;
    }

    .tinymce-wrapper .tox-tinymce {
        border-radius: 0.375rem;
    }

    .fi-fo-field-wrp {
        margin-top: 1rem;
    }
</style>

<?php /**PATH /data/home/cerita_oca/Documents/iza/mundial_project1/mundial/resources/views/filament/forms/components/tinymce-editor.blade.php ENDPATH**/ ?>