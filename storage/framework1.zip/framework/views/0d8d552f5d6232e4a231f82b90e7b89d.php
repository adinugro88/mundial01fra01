<?php $__env->startSection('title', 'Restaurant - Mundial'); ?>

<?php $__env->startSection('content'); ?>
<main id="main-content" class="main-content">
  <div class="w-container">
    <a href="<?php echo e(route('offers')); ?>" class="back w-inline-block">
      <img src="<?php echo e(asset('images/back.svg')); ?>" loading="lazy" alt="" class="image-26">
      <div class="text-block-7"><?php echo e(trans_db('offer.back_to_offers', null, 'À la liste des offres')); ?></div>
    </a>
  </div>
  <div class="w-container">
    <div class="div-block-51"></div>
    <div class="w-richtext">
      <p>‍</p>
      <h2><?php echo e(trans_db('offer.restaurant.title', null, 'Restaurant')); ?></h2>
      <p><?php echo trans_db('offer.restaurant.intro', null, 'Profitez de notre restaurant au Centro de Loisirs Mundial avec une cuisine délicieuse et une ambiance agréable.'); ?></p>
      <p><?php echo trans_db('offer.restaurant.menu', null, 'Notre menu varie et propose des plats traditionnels ainsi que des spécialités régionales. Tous les plats sont préparés avec des ingrédients frais et de qualité.'); ?></p>
      <p><?php echo trans_db('offer.restaurant.ambiance', null, 'Que ce soit pour un déjeuner rapide, un dîner en famille ou une célébration spéciale, notre restaurant offre le cadre idéal avec une vue magnifique sur nos installations de loisirs.'); ?></p>
      <p>‍</p>
    </div>
    <div class="div-block-209">
      <a href="#" class="primary-button w-button"><?php echo e(trans_db('offer.button_reservation', null, 'Faire une réservation')); ?></a>
    </div>
  </div>
  <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/home/cerita_oca/Documents/iza/mundial_project1/mundial/resources/views/angebote-restaurant.blade.php ENDPATH**/ ?>