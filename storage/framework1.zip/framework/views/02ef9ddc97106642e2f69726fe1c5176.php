<p
    <?php echo e($attributes->class(['fi-modal-description text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /data/home/cerita_oca/Documents/iza/mundial_project1/mundial/vendor/filament/support/resources/views/components/modal/description.blade.php ENDPATH**/ ?>