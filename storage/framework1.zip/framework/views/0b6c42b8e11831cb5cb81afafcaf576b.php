<?php $__env->startSection('title', 'Fête d\'Anniversaire - Mundial'); ?>

<?php $__env->startSection('content'); ?>
<main id="main-content" class="main-content">
  <div class="w-container">
    <a href="<?php echo e(route('offers')); ?>" class="back w-inline-block">
      <img src="<?php echo e(asset('images/back.svg')); ?>" loading="lazy" alt="" class="image-26">
      <div class="text-block-7"><?php echo e(trans_db('offer.back_to_offers', null, 'À la liste des offres')); ?></div>
    </a>
  </div>
  <div class="w-container">
    <div class="div-block-50"></div>
    <div class="w-richtext">
      <p>‍</p>
      <h2><?php echo e(trans_db('offer.birthday.title', null, 'Fête d\'Anniversaire')); ?></h2>
      <p><?php echo trans_db('offer.birthday.intro', null, 'Célébrez votre anniversaire au Centro de Loisirs Mundial ! Nous proposons des forfaits d\'anniversaire personnalisés avec diverses activités.'); ?></p>
      <p><?php echo trans_db('offer.birthday.packages', null, 'Choisissez parmi nos différents forfaits d\'anniversaire incluant piscine, bowling, sauna ou minigolf. Des packages personnalisés sont disponibles pour tous les âges et budgets.'); ?></p>
      <p>‍</p>
    </div>
    <div class="div-block-209">
      <a href="#" class="primary-button w-button"><?php echo e(trans_db('offer.button_book', null, 'Réserver')); ?></a>
    </div>
  </div>
  <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/home/cerita_oca/Documents/iza/mundial_project1/mundial/resources/views/angebote-birthday.blade.php ENDPATH**/ ?>