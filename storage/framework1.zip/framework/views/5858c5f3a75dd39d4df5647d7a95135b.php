<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /data/home/cerita_oca/Documents/iza/mundial_project1/mundial/vendor/filament/support/resources/views/components/dropdown/list/index.blade.php ENDPATH**/ ?>