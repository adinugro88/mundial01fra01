<?php $__env->startSection('title', '@yield("page_title") - Mundial'); ?>

<?php $__env->startSection('content'); ?>
<main id="main-content" class="main-content">
  <div class="w-container">
    <div>
      <a href="<?php echo e(route('home')); ?>" class="back-copy w-inline-block">
        <img src="<?php echo e(asset('images/back.svg')); ?>" loading="lazy" alt="" class="image-26">
        <div class="text-block-7"><?php echo e(trans_db('offer.back_to_offers', null, 'À la liste des offres')); ?></div>
      </a>
    </div>
    <h2 class="heading-12"><?php echo $__env->yieldContent('page_title'); ?></h2>
    <div class="w-richtext">
      <?php echo $__env->yieldContent('angebote-content'); ?>
    </div>
  </div>
  <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/home/cerita_oca/Documents/iza/mundial_project1/mundial/resources/views/angebote.blade.php ENDPATH**/ ?>