<p
    <?php echo e($attributes->class(['fi-ta-empty-state-description text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /data/home/cerita_oca/Documents/iza/mundial_project1/mundial/vendor/filament/tables/resources/views/components/empty-state/description.blade.php ENDPATH**/ ?>