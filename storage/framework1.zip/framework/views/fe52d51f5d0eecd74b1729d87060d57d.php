<div data-collapse="tiny" data-animation="default" data-duration="400" role="banner" class="navbar w-nav">
  <div class="container-6 w-container">
    <a href="<?php echo e(route('home')); ?>" aria-current="page" class="w-inline-block <?php echo e(request()->routeIs('home') ? 'w--current' : ''); ?>">
      <img src="<?php echo e(asset('images/logo1_v3.svg')); ?>" height="40" alt="" class="image">
    </a>
    <nav role="navigation" class="w-nav-menu">
      <a href="<?php echo e(route('offers')); ?>" class="nav-link-2 w-nav-link <?php echo e(request()->routeIs('offers', 'angebote*') ? 'w--current' : ''); ?>">
        <?php echo e(trans_db('nav.offers')); ?>

      </a>
      <a href="<?php echo e(route('prices')); ?>" class="nav-link-2 w-nav-link <?php echo e(request()->routeIs('prices') ? 'w--current' : ''); ?>">
        <?php echo e(trans_db('nav.prices')); ?>

      </a>
      <a href="<?php echo e(route('contact')); ?>" class="nav-link-2 w-nav-link <?php echo e(request()->routeIs('contact') ? 'w--current' : ''); ?>">
        <?php echo e(trans_db('nav.contact')); ?>

      </a>
      
    </nav>
    <a href="<?php echo e(route('task')); ?>" class="button-task-header w-button"><?php echo e(trans_db('nav.task')); ?></a>
    <div class="menu-button w-nav-button">
      <div class="icon w-icon-nav-menu"></div>
    </div>
  </div>
</div>
<?php /**PATH /data/home/cerita_oca/Documents/iza/mundial_project1/mundial/resources/views/components/navbar.blade.php ENDPATH**/ ?>