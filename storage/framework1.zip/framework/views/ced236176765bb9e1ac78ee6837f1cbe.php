<?php $__env->startSection('title', 'Piscine - Mundial'); ?>

<?php $__env->startSection('content'); ?>
<main id="main-content" class="main-content">
  <div class="w-container">
    <a href="<?php echo e(route('offers')); ?>" class="back w-inline-block">
      <img src="<?php echo e(asset('images/back.svg')); ?>" loading="lazy" alt="" class="image-26">
      <div class="text-block-7"><?php echo e(trans_db('offer.back_to_offers', null, 'À la liste des offres')); ?></div>
    </a>
  </div>
  <div class="w-container">
    <div class="div-block-45"></div>
    <div class="w-richtext">
      <p>‍</p>
      <h2><?php echo e(trans_db('offer.hallenbad.indoor_title', null, 'Piscine intérieure')); ?></h2>
      <p><?php echo trans_db('offer.hallenbad.indoor_desc', null, 'Notre piscine intérieure moderne offre un grand plaisir de baignade aux nageurs sportifs ainsi qu\'aux familles et aux amis. Le bain a une piscine de 50 mètres et promet un plaisir illimité pour petits et grands avec trois toboggans aquatiques. Que ce soit dans des chambres à air colorées, sur des pneus souples ou en chute libre, le plaisir de la glisse est garanti. Divisé en trois niveaux, votre favori parmi les toboggans aquatiques est sûr d\'être trouvé rapidement. Nous organisons aussi régulièrement des événements récréatifs, tels que des spectacles de plongée en hauteur ou des rencontres de sirènes. Non seulement pour les actifs, mais aussi pour les spectateurs un grand plaisir sportif. De plus, les diapositives sont un point fort pour nos jeunes visiteurs.'); ?></p>
      <p>‍</p>
      <p>‍</p>
    </div>
    <div class="div-block-45-copy"></div>
    <div class="w-richtext">
      <p>‍</p>
      <h2><?php echo e(trans_db('offer.hallenbad.natural_title', null, 'Piscine naturelle')); ?></h2>
      <p><?php echo trans_db('offer.hallenbad.natural_desc', null, 'Notre piscine naturelle offre une eau de baignade qualitativement comparable à celle d\'un lac naturel ou d\'un étang profond. Profitez des plaisirs de la baignade naturelle dans une eau sans chlore ni produits chimiques.'); ?></p>
      <p>‍</p>
      <p>‍</p>
      <p>‍</p>
    </div>
  </div>
  <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/home/cerita_oca/Documents/iza/mundial_project1/mundial/resources/views/angebote-hallenbad.blade.php ENDPATH**/ ?>