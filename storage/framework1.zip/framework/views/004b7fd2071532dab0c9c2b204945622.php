<time
    <?php echo e($attributes->class(['fi-no-notification-date text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</time>
<?php /**PATH /data/home/cerita_oca/Documents/iza/mundial_project1/mundial/vendor/filament/notifications/resources/views/components/date.blade.php ENDPATH**/ ?>